import { withSupabase } from "jsr:@supabase/auth-helpers@0.10.0";
Deno.serve(withSupabase({auth:"user"},async(req,ctx)=>{
 const origin=req.headers.get("origin")||"https://fuelthefire.site";
 const headers={"Access-Control-Allow-Origin":origin,"Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS","Vary":"Origin","Content-Type":"application/json"};
 const reply=(body,status=200)=>new Response(JSON.stringify(body),{status,headers});
 if(req.method==="OPTIONS")return new Response("ok",{headers});if(req.method!=="POST")return reply({error:"POST required"},405);
 const {data:{user},error:ue}=await ctx.supabase.auth.getUser();if(ue||!user)return reply({error:"Sign in required"},401);
 const {data:actor}=await ctx.supabase.from("profiles").select("role,active").eq("id",user.id).single();
 if(!actor?.active||actor.role!=="admin")return reply({error:"Administrator permission required"},403);
 const b=await req.json(),id=String(b.user_id||""),action=String(b.action||"");if(!id)return reply({error:"user_id required"},400);
 const {data:target}=await ctx.supabaseAdmin.from("profiles").select("id,role").eq("id",id).maybeSingle();
 if(!target)return reply({error:"Profile not found"},404);if(target.role==="admin")return reply({error:"This endpoint does not modify admin accounts"},400);
 let result;
 if(["activate","deactivate","force_password_change"].includes(action)){
  const patch={};if(action==="activate")patch.active=true;if(action==="deactivate")patch.active=false;if(action==="force_password_change")patch.must_change_password=true;
  result=await ctx.supabaseAdmin.from("profiles").update(patch).eq("id",id);
 }else if(action==="reset_password"){
  const password=String(b.temporary_password||"");if(password.length<12)return reply({error:"Temporary password must be at least 12 characters"},400);
  result=await ctx.supabaseAdmin.auth.admin.updateUserById(id,{password});
  if(!result.error)result=await ctx.supabaseAdmin.from("profiles").update({must_change_password:true}).eq("id",id);
 }else return reply({error:"Unsupported action"},400);
 if(result?.error)return reply({error:result.error.message},400);
 await ctx.supabaseAdmin.from("audit_logs").insert({user_id:user.id,action:`employee_${action}`,entity_type:"profile",entity_id:id,metadata:{target_user_id:id}});
 return reply({success:true});
}));